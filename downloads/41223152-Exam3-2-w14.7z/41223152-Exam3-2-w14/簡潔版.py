# pip install websocket-server
import threading
import socket
import json
from websocket_server import WebsocketServer
from controller import Supervisor

SEGMENT_DEFS = [
    ["seven_segment_a1","seven_segment_b1","seven_segment_c1","seven_segment_d1","seven_segment_e1","seven_segment_f1","seven_segment_g1"],  # 1位
    ["seven_segment_a2","seven_segment_b2","seven_segment_c2","seven_segment_d2","seven_segment_e2","seven_segment_f2","seven_segment_g2"],  # 2位
    ["seven_segment_a3","seven_segment_b3","seven_segment_c3","seven_segment_d3","seven_segment_e3","seven_segment_f3","seven_segment_g3"],  # 3位 (固定顯示1)
    ["seven_segment_a4","seven_segment_b4","seven_segment_c4","seven_segment_d4","seven_segment_e4","seven_segment_f4","seven_segment_g4"],  # 4位
    ["seven_segment_a5","seven_segment_b5","seven_segment_c5","seven_segment_d5","seven_segment_e5","seven_segment_f5","seven_segment_g5"],  # 5位
    ["seven_segment_a6","seven_segment_b6","seven_segment_c6","seven_segment_d6","seven_segment_e6","seven_segment_f6","seven_segment_g6"],  # 6位
    ["seven_segment_a7","seven_segment_b7","seven_segment_c7","seven_segment_d7","seven_segment_e7","seven_segment_f7","seven_segment_g7"],  # 7位
    ["seven_segment_a8","seven_segment_b8","seven_segment_c8","seven_segment_d8","seven_segment_e8","seven_segment_f8","seven_segment_g8"],  # 8位
]

SEGMENT_NUMS = {
    0:[1,1,1,1,1,1,0],
    1:[0,1,1,0,0,0,0],
    2:[1,1,0,1,1,0,1],
    3:[1,1,1,1,0,0,1],
    4:[0,1,1,0,0,1,1],
    5:[1,0,1,1,0,1,1],
    6:[1,0,1,1,1,1,1],
    7:[1,1,1,0,0,0,0],
    8:[1,1,1,1,1,1,1],
    9:[1,1,1,1,0,1,1]
}

class SevenSegs:
    def __init__(self, supervisor, color_on, color_off):
        self.supervisor = supervisor
        self.color_on, self.color_off = color_on, color_off
        self.nodes = []
        for defs in SEGMENT_DEFS:
            fields = []
            for d in defs:
                node = supervisor.getFromDef(d)
                try:
                    fields.append(node.getField("appearance").getSFNode().getField("material").getSFNode().getField("diffuseColor"))
                except: fields.append(None)
            self.nodes.append(fields)
        # 3號位固定顯示1
        self.set_digit(2, 1)
        # 額外5位靜態顯示
        for idx,val in enumerate([None,None,None,3,2,2,1,4]):
            if val is not None: self.set_digit(idx, val)

    def set_digit(self, idx, value):
        if 0<=idx<len(self.nodes) and self.nodes[idx][0]:
            pattern = SEGMENT_NUMS.get(value, SEGMENT_NUMS[0])
            for i,seg_on in enumerate(pattern):
                self.nodes[idx][i].setSFVec3f(self.color_on if seg_on else self.color_off)

    def display(self, number):
        # 只顯示十位與個位（第1、2組顯示器），3號位不動
        if not (0 <= number <= 999): return
        t, u = (number%100)//10, number%10
        self.set_digit(1, t)
        self.set_digit(0, u)

class WSSevenSegmentServer:
    def __init__(self, ipv6, port):
        self.seq_up = [18, 22, 31, 36]
        self.seq_down = [18, 36, 31, 22]
        self.cur = 18
        self.supervisor = Supervisor()
        self.timestep = int(self.supervisor.getBasicTimeStep())
        self.ctrl = SevenSegs(self.supervisor, [0,1,0], [0,0,0])
        self.ctrl.display(self.cur)

        class IPv6WebsocketServer(WebsocketServer):
            def __init__(s, host, port):
                s.address_family = socket.AF_INET6
                super().__init__(host=host, port=port)
        self.wss = IPv6WebsocketServer(host=ipv6, port=port)
        self.wss.set_fn_message_received(self.on_message)

    def on_message(self, client, server, msg):
        try:
            data = json.loads(msg)
            cmd = str(data.get('cmd', '') if isinstance(data, dict) else data).strip().upper()
        except: cmd = str(msg).strip().upper()
        if cmd == "W":
            seq, idx = self.seq_down, self.seq_down.index(self.cur) if self.cur in self.seq_down else 0
            self.cur = seq[(idx+1)%len(seq)]
            self.ctrl.display(self.cur)
            server.send_message(client, f"W切換到: {self.cur}")
        elif cmd == "S":
            seq, idx = self.seq_up, self.seq_up.index(self.cur) if self.cur in self.seq_up else 0
            self.cur = seq[(idx+1)%len(seq)]
            self.ctrl.display(self.cur)
            server.send_message(client, f"S切換到: {self.cur}")
        else:
            server.send_message(client, f"未處理的訊息: {msg}")

    def run_wss(self):
        self.wss.run_forever()

    def run_supervisor(self):
        while self.supervisor.step(self.timestep) != -1: pass

    def run(self):
        threading.Thread(target=self.run_wss, daemon=True).start()
        threading.Thread(target=self.run_supervisor, daemon=True).start()
        while True: pass

if __name__ == "__main__":
    ipv6 = "2001:288:6004:17:fff1:cd25:0:a039"
    port = 8081
    WSSevenSegmentServer(ipv6, port).run()
